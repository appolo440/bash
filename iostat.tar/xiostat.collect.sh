# Extanded check iostat module
#
# Script write by Vasily V. Yakunin
# for more info or trublle please contact to autor.
# vasily.yakunin@gmail.com
#
# You most add xiostat.collect.sh to /etc/crontab file every one minute or what like you want.
#
#!/bin/sh

# Set path variable where report file will be locaited 
# (it will be plase where parser script locaited or in /etc/zabbix/zabbix_agentd.d/)
# For more info abut iostat key, you got in documentation's

path="xiostat.log"
iostat -x -t 1 -c 3 | tail -n +24 > ${path}