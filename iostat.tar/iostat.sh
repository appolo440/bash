# Simple check iostat module
# Programm parametr's: 
# tps
# kB_read/s
# kB_wrtn/s
# kB_read
# kB_wrtn
# cat ${log_path} | grep $1 | awk {'print $2'}

#!/bin/bash

# Set path variable

log_path="iostat.log"

if [ -z $1 ]; then
	echo "Укажите тип устройства"
	exit 0
else
	if [ -z $2 ]; then
	echo "Укажите необходимый параметр"
	exit 0
	
	elif [ $2 = "tps" ]; then
	cat ${log_path} | grep $1 | awk {'print $2'}
	
	elif [ $2 = "kbread_s" ]; then
	cat ${log_path} | grep $1 | awk {'print $3'}

	elif [ $2 = "kbwrite_s" ]; then
	cat ${log_path} | grep $1 | awk {'print $4'}

	elif [ $2 = "kb_read" ]; then
	cat ${log_path} | grep $1 | awk {'print $5'}

	elif [ $2 = "kb_write" ]; then
	cat ${log_path} | grep $1 | awk {'print $6'}

	fi		
fi
