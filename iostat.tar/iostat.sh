# Simple check iostat module
#
# Script write by Vasily V. Yakunin
# for more info or trublle please contact to autor.
# vasily.yakunin@gmail.com
#
# You most add iostat.collect.sh to /etc/crontab file every one minute or what like you want.
#
# Programm parametr's: 
# Use Zabbix key paramerts to get what you wish.
# Sample: iostat[sda,tps] it's return params of tps value
#
# tps			=	tps
# kB_read/s		=	kbread_s
# kB_wrtn/s		=	kbwrite_s
# kB_read		=	kb_read
# kB_wrtn		=	kb_write
#
#!/bin/bash

# Set path variable

log_path="iostat.log"

if [ -z $1 ]; then
	echo "Please enter device name, sample: sda"
	exit 0
else
	if [ -z $2 ]; then
	echo "Please enter parametr name, sample: tps"
	exit 0

	elif [ $2 = "tps" ]; then
	cat ${log_path} | grep $1 | awk {'print $2'}

	elif [ $2 = "kbread_s" ]; then
	cat ${log_path} | grep $1 | awk {'print $3'}

	elif [ $2 = "kbwrite_s" ]; then
	cat ${log_path} | grep $1 | awk {'print $4'}

	elif [ $2 = "kb_read" ]; then
	cat ${log_path} | grep $1 | awk {'print $5'}

	elif [ $2 = "kb_write" ]; then
	cat ${log_path} | grep $1 | awk {'print $6'}
	fi		
fi