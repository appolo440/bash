# Program parametr's -x
# rrqm/s
# wrqm/s
# r/s
# w/s
# rkB/s
# wkB/s
# avgrq-sz
# avgqu-sz
# await
# r_await
# w_await
# svctm
# %util

#!/bin/bash
# Set path variable

log_path="xiostat.log"

if [ -z $1 ]; then
	echo "Укажите тип устройства"
	exit 0
else
	if [ -z $2 ]; then
	echo "Укажите необходимый параметр"
	exit 0
	
	elif [ $2 = "rrqms" ]; then
	cat ${log_path} | grep $1 | awk {'print $2'}

	elif [ $2 = "wrqms" ]; then
	cat ${log_path} | grep $1 | awk {'print $3'}

	elif [ $2 = "rs" ]; then
	cat ${log_path} | grep $1 | awk {'print $4'}

	elif [ $2 = "ws" ]; then
	cat ${log_path} | grep $1 | awk {'print $5'}

	elif [ $2 = "rkbs" ]; then
	cat ${log_path} | grep $1 | awk {'print $6'}

	elif [ $2 = "wkbs" ]; then
	cat ${log_path} | grep $1 | awk {'print $7'}

	elif [ $2 = "avgrq-sz" ]; then
	cat ${log_path} | grep $1 | awk {'print $8'}	

	elif [ $2 = "avgqu-sz" ]; then
	cat ${log_path} | grep $1 | awk {'print $9'}	

	elif [ $2 = "await" ]; then
	cat ${log_path} | grep $1 | awk {'print $10'}	

	elif [ $2 = "r_await" ]; then
	cat ${log_path} | grep $1 | awk {'print $11'}	

	elif [ $2 = "w_await" ]; then
	cat ${log_path} | grep $1 | awk {'print $12'}	

	elif [ $2 = "svctm" ]; then
	cat ${log_path} | grep $1 | awk {'print $13'}	

	elif [ $2 = "util" ]; then
	cat ${log_path} | grep $1 | awk {'print $14'}	

	fi		
fi
